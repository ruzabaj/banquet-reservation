import React from 'react'

const NepaliCalendar = () => {
  return (
    <div>NepaliCalendar</div>
  )
}

export default NepaliCalendar