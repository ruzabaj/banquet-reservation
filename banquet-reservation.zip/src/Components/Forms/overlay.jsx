import React from 'react'
import "../../Assets/Styles/overlay.scss";

const Overlay = () => {
    return (
        <center>
            <div class="container">
                <img src="jtp.png" />
                <div class="overlay"></div>
            </div>
        </center>
    )
}

export default Overlay