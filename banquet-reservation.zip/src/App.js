import './App.css';
import Register from './Pages/Register';

function App() {
  return (
    <div className="App">
      <Register/>
    </div>
  );
}

export default App;
